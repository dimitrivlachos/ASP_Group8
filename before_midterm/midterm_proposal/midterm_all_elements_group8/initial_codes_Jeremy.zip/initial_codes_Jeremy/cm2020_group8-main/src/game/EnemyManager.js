import { GameObject } from "./GameObject.js";

export class EnemyManager extends GameObject {
    constructor() {
        super();
    }
}